// i18n.config.ts
export default defineI18nConfig(() => ({
    legacy: false,
    locale: 'en',
    fallbackLocale: 'en',
    messages: {
      en: { welcome: 'Welcome' },
      de: { welcome: 'Willkommen' },
    },
  }))
  