<template>
  <div class="p-6">
    <h1 class="text-3xl font-bold mb-4">{{ $t('nav.blog') }}</h1>

    <ul v-if="posts?.length">
      <li
        v-for="post in posts"
        :key="post._path"
        class="mb-4 p-4 border rounded hover:bg-gray-50 transition"
      >
        <NuxtLink :to="post._path">
          <h2 class="text-xl font-semibold">{{ post.title }}</h2>
          <p class="text-gray-600">{{ post.description }}</p>
        </NuxtLink>
      </li>
    </ul>

    <p v-else class="text-gray-500">No posts found.</p>
  </div>
</template>

<script setup>
import { useI18n } from 'vue-i18n'

const { locale } = useI18n()

console.log('Current locale:', locale.value);

const { data: posts } = await useAsyncData(() =>
  queryContent('content')
    .only(['title', 'description'])
    .find()
)
console.log('Posts:', posts.value)
</script>
