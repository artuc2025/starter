<template>
    <div class="max-w-3xl mx-auto px-4 py-10">
      <h1 class="text-3xl font-semibold mb-4">About This Blog</h1>
      <p class="text-text-2">
        This blog was built with Nuxt 3 and Tailwind CSS. It's minimal and easy to scale.
      </p>
    </div>
  </template>
  
  <script setup lang="ts">
useSeoMetaTags({
  title: 'About - My Blog',
  description: 'Learn more about the author and purpose of this blog.',
})
</script>
