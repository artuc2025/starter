<!-- layouts/default.vue -->
<template>
    <div>
      <Header />
      <main class="min-h-[70vh]">
        <slot />
      </main>
      <Footer />
    </div>
  </template>
  