---
title: First English Post
description: This is the first blog post in English.
_locale: en
---

# Hello from English

Welcome to the English version of this blog post.
