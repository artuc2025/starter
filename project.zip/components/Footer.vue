<template>
    <footer class="text-center py-6 text-sm text-gray-500">
      &copy; {{ new Date().getFullYear() }} My Nuxt Blog. All rights reserved.
    </footer>
  </template>
  